def calculate_risk(headers_result, ssl_result):
    score = 0

    # Missing security headers increase risk
    for status in headers_result.values():
        if status == "Missing":
            score += 1

    # SSL issues increase risk
    if ssl_result.get("ssl") != "Valid SSL":
        score += 2

    # Final risk classification
    if score <= 1:
        return "🟢 LOW"
    elif score <= 3:
        return "🟠 MEDIUM"
    else:
        return "🔴 HIGH"
