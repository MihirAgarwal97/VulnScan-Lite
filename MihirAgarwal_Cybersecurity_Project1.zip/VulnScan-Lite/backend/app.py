from flask import Flask, render_template, request
import requests
import ssl
import socket
import webbrowser
import threading
import time
from urllib.parse import urlparse

app = Flask(__name__)

# -------------------------------------------------
# AUTO OPEN BROWSER
# -------------------------------------------------
def wait_and_open_browser(host="127.0.0.1", port=5000):
    while True:
        try:
            with socket.create_connection((host, port), timeout=1):
                break
        except OSError:
            time.sleep(0.5)
    webbrowser.open_new(f"http://{host}:{port}")

# -------------------------------------------------
# SECURITY HEADERS CHECK
# -------------------------------------------------
def check_headers(url):
    result = {
        "CSP": False,
        "X-Frame-Options": False,
        "X-Content-Type-Options": False,
        "Server": "Unknown"
    }

    response = requests.get(url, timeout=5)
    headers = response.headers

    if "Content-Security-Policy" in headers:
        result["CSP"] = True

    if "X-Frame-Options" in headers:
        result["X-Frame-Options"] = True

    if "X-Content-Type-Options" in headers:
        result["X-Content-Type-Options"] = True

    result["Server"] = headers.get("Server", "Unknown")
    return result

# -------------------------------------------------
# SSL CHECK
# -------------------------------------------------
def check_ssl(url):
    try:
        domain = urlparse(url).netloc
        context = ssl.create_default_context()
        with socket.create_connection((domain, 443), timeout=5) as sock:
            with context.wrap_socket(sock, server_hostname=domain):
                return "Valid SSL"
    except:
        return "Invalid / No SSL"

# -------------------------------------------------
# COOKIE CHECK
# -------------------------------------------------
def check_cookies(url):
    cookies_info = []
    response = requests.get(url, timeout=5)

    for cookie in response.cookies:
        cookies_info.append({
            "name": cookie.name,
            "secure": cookie.secure,
            "httponly": cookie.has_nonstandard_attr("HttpOnly")
        })

    if not cookies_info:
        return "No cookies found"

    return cookies_info

# -------------------------------------------------
# RISK SCORING ENGINE
# -------------------------------------------------
def calculate_risk(headers_result, ssl_result):
    score = 0

    if not headers_result.get("CSP"):
        score += 2

    if not headers_result.get("X-Content-Type-Options"):
        score += 1

    if not headers_result.get("X-Frame-Options"):
        score += 1

    if ssl_result != "Valid SSL":
        score += 2

    if score >= 4:
        return "🔴 HIGH"
    elif score >= 2:
        return "🟠 MEDIUM"
    else:
        return "🟢 LOW"

# -------------------------------------------------
# RECOMMENDATIONS
# -------------------------------------------------
def recommendations(result):
    advice = []
    headers = result.get("headers", {})
    ssl_status = result.get("ssl", "")

    if not headers.get("CSP"):
        advice.append("Add Content-Security-Policy header to prevent XSS attacks.")

    if not headers.get("X-Content-Type-Options"):
        advice.append("Add X-Content-Type-Options header to prevent MIME sniffing.")

    if not headers.get("X-Frame-Options"):
        advice.append("Add X-Frame-Options header to prevent clickjacking.")

    if ssl_status != "Valid SSL":
        advice.append("Use HTTPS with a valid SSL certificate.")

    if not advice:
        advice.append("No major security issues detected.")

    return advice

# -------------------------------------------------
# MAIN ROUTE
# -------------------------------------------------
def detect_cms(url):
    try:
        response = requests.get(url, timeout=5)
        html = response.text.lower()
        headers = response.headers

        if "wp-content" in html or "wordpress" in html:
            return "WordPress"
        elif "joomla" in html:
            return "Joomla"
        elif "drupal" in html:
            return "Drupal"
        else:
            return "Unknown / Custom CMS"
    except:
        return "CMS Detection Failed"
def cms_vulnerabilities(cms):
    vulnerabilities = {
        "WordPress": [
            "Outdated plugins and themes",
            "XML-RPC brute-force attacks",
            "Insecure admin credentials"
        ],
        "Joomla": [
            "Outdated extensions",
            "Misconfigured permissions",
            "Known core vulnerabilities"
        ],
        "Drupal": [
            "Drupalgeddon vulnerabilities",
            "Weak access controls"
        ]
    }

    return vulnerabilities.get(cms, ["No known common vulnerabilities detected"])
@app.route("/", methods=["GET", "POST"])
def index():
    result = {}
    risk = ""
    advice = []

    if request.method == "POST":
        url = request.form.get("url", "").strip()

        if not url:
            result = {"error": "Please enter a valid URL"}
        else:
            if not url.startswith("http"):
                url = "https://" + url

            try:
                headers_data = check_headers(url)
                ssl_data = check_ssl(url)
                cookies_data = check_cookies(url)
                cms = detect_cms(url)
                cms_issues = cms_vulnerabilities(cms)
                result = {
                    "url": url,
                    "headers": headers_data,
                    "ssl": ssl_data,
                    "cookies": cookies_data,
                    "cms": cms,
                    "cms_issues": cms_issues
     }

                risk = calculate_risk(headers_data, ssl_data)
                advice = recommendations(result)

            except Exception as e:
                result = {"error": str(e)}

    return render_template(
        "index.html",
        result=result,
        risk=risk,
        advice=advice
    )

# -------------------------------------------------
# ENTRY POINT
# -------------------------------------------------
if __name__ == "__main__":
    threading.Thread(target=wait_and_open_browser).start()
    app.run(debug=True)

