import requests

def check_cookies(url):
    results = []

    try:
        response = requests.get(url, timeout=5)

        for cookie in response.cookies:
            cookie_info = {
                "name": cookie.name,
                "secure": cookie.secure,
                "httponly": cookie.has_nonstandard_attr("HttpOnly"),
                "samesite": cookie._rest.get("samesite", "Not Set")
            }
            results.append(cookie_info)

        if not results:
            return {"cookies": "No cookies found"}

        return {"cookies": results}

    except Exception as e:
        return {"error": str(e)}
